package com.mygdx.game;

public class QuitConfirm {
}
